import users from './data.mjs';

// melihat data
const index = () => {
  users.map((user, i) => {
    console.log(`${i + 1}. ${user.nama} | ${user.umur} tahun | ${user.alamat} | ${user.email}`);
  });
};

// menambah data
const store = (user) => {
  users.push(user);
};

// menghapus data terakhir
const destroy = () => {
  users.pop();
};

export { index, store, destroy };
