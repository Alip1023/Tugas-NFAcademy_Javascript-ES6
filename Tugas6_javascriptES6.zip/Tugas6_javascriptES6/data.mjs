const users = [
  { nama: 'Zufar', umur: 20, alamat: 'Jl. Tanjung Duren Raya, Grogol, Jakarta Barat', email: 'zufar@gmail.com' },
  { nama: 'Akas', umur: 20, alamat: 'Jl. Tomang Raya, Grogol Petamburan, Jakarta Barat', email: 'akas@gmail.com' },
  { nama: 'Kahfi', umur: 21, alamat: 'Jl. Kyai Tapa, Grogol, Jakarta Barat', email: 'kahfi@gmail.com' },
  { nama: 'Dafa', umur: 20, alamat: 'Jl. Daan Mogot, Kalideres, Jakarta Barat', email: 'dafa@gmail.com' },
  { nama: 'Tebe', umur: 21, alamat: 'Jl. Panjang, Kebon Jeruk, Jakarta Barat', email: 'tebe@gmail.com' },
  { nama: 'Kus', umur: 20, alamat: 'Jl. Palmerah Barat, Palmerah, Jakarta Barat', email: 'kus@gmail.com' },
  { nama: 'Inu', umur: 22, alamat: 'Jl. Meruya Ilir Raya, Kembangan, Jakarta Barat', email: 'inu@gmail.com' },
  { nama: 'Arbi', umur: 21, alamat: 'Jl. Petamburan III, Tanah Abang, Jakarta Pusat', email: 'arbi@gmail.com' },
  { nama: 'Fatur', umur: 20, alamat: 'Jl. Kebon Jeruk Raya, Kebon Jeruk, Jakarta Barat', email: 'fatur@gmail.com' },
  { nama: 'Malik', umur: 22, alamat: 'Jl. Letjen S. Parman, Slipi, Jakarta Barat', email: 'malik@gmail.com' },
];

export default users;
