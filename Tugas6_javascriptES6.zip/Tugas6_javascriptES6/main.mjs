import { index, store, destroy } from './controller.mjs';

const main = () => {
  // tambah dua data
  store({ nama: 'Rafi', umur: 21, alamat: 'Jl. Latumenten, Jelambar, Jakarta Barat', email: 'rafi@gmail.com' });
  store({ nama: 'Naufal', umur: 20, alamat: 'Jl. Pejagalan Raya, Penjaringan, Jakarta Utara', email: 'naufal@gmail.com' });

  console.log('Setelah ditambah:');
  index();

  destroy();

  console.log('\nSetelah dihapus:');
  index();
};

main();